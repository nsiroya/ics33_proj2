class Poly:
    pass

   


    
if __name__ == '__main__':
    #Simple tests before running driver
    #Put your own test code here to test Poly before doing bsc tests
    #Debugging problems with tests is simpler

    print('Start of simple tests')
    p = Poly((3,2),(-2,1),(4,0))
    print('  For Polynomial: 3x^2 - 2x + 4')
    print('  str(p):',p)
    print('  repr(p):',repr(p))
    print('  len(p):',len(p))
    print('  p(2):',p(2))
    print('  list collecting the iterator results:', [t for t in p])
    print('  p+p:',p+p)
    print('  p+2:',p+2)
    print('  p*p:',p*p)
    print('  p*2:',p*2)
    print('End of simple tests\n\n')
    
    import driver
    driver.default_file_name = 'bscp22W20.txt'
#     driver.default_show_exception= True
#     driver.default_show_exception_message= True
#     driver.default_show_traceback= True
    driver.driver()     
